import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-funcionarios',
  templateUrl: './funcionarios.page.html',
  styleUrls: ['./funcionarios.page.scss'],
  standalone: false
})
export class FuncionariosPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
