import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-funcionario',
  templateUrl: './add-funcionario.page.html',
  styleUrls: ['./add-funcionario.page.scss'],
  standalone: false
})
export class AddFuncionarioPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
