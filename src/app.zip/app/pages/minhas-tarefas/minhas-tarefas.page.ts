import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-minhas-tarefas',
  templateUrl: './minhas-tarefas.page.html',
  styleUrls: ['./minhas-tarefas.page.scss'],
  standalone: false
})
export class MinhasTarefasPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
