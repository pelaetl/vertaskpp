import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-todas-tarefas',
  templateUrl: './todas-tarefas.page.html',
  styleUrls: ['./todas-tarefas.page.scss'],
  standalone: false
})
export class TodasTarefasPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
