import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-tarefa',
  templateUrl: './add-tarefa.page.html',
  styleUrls: ['./add-tarefa.page.scss'],
  standalone: false
})
export class AddTarefaPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
