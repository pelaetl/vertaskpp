import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-setor',
  templateUrl: './add-setor.page.html',
  styleUrls: ['./add-setor.page.scss'],
  standalone: false
})
export class AddSetorPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
