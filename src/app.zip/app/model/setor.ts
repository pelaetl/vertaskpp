export class Setor {

    idSetor: number;
    nome: string;
    descricao: string;

    constructor() {
        this.idSetor = 0;
        this.nome = '';
        this.descricao = '';
    }
    
}
