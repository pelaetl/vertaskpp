import { Funcionario } from './funcionario';

describe('Funcionario', () => {
  it('should create an instance', () => {
    expect(new Funcionario()).toBeTruthy();
  });
});
