import { Tarefa } from './tarefa';

describe('Tarefa', () => {
  it('should create an instance', () => {
    expect(new Tarefa()).toBeTruthy();
  });
});
