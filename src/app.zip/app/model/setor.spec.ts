import { Setor } from './setor';

describe('Setor', () => {
  it('should create an instance', () => {
    expect(new Setor()).toBeTruthy();
  });
});
